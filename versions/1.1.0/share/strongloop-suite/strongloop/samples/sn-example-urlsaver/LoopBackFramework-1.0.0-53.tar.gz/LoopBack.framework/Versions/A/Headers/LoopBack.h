/**
 * @file LoopBack.h
 *
 * @author Michael Schoonmaker
 * @copyright (c) 2013 StrongLoop. All rights reserved.
 */

#import "LBModel.h"
#import "LBRESTAdapter.h"
